# sql_rockbuster
A Compilation if SQL queries for a Relational Database of a fictional Movie Rental company.
## Objective
Rockbuster Stealth LLC is a movie rental company that used to have stores around the
world. Facing stiff competition from streaming services such as Netflix and Amazon Prime,
the Rockbuster Stealth management team is planning to use its existing movie licenses to
launch an online video rental service in order to stay competitive. 
My job as a data analyst in Business Intelligence was to provide data-driven answers to 
important business questions using SQL

